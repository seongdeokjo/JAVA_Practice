package test;

public interface AccountInfo {
	public static void deposit(Account a) {
		
	}
	public static void withdraw(Account a) {
		
	}
}
