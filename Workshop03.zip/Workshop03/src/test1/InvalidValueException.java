package test1;
public class InvalidValueException extends Exception {
    public InvalidValueException(String msg) {
        super(msg);
    }
}