package com.test.workshop3.exception;

public class Manager {

}
